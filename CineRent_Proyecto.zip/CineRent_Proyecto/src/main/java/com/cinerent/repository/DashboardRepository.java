package com.cinerent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cinerent.model.Rental;

@Repository
public interface DashboardRepository extends JpaRepository<Rental, Integer> {

    // Total de alquileres
    @Query(value = "SELECT COUNT(*) FROM rental", nativeQuery = true)
    long totalRentals();

    // Ingresos totales
    @Query(value = "SELECT COALESCE(SUM(amount), 0) FROM payment", nativeQuery = true)
    double totalIncome();

    // Clientes activos
    @Query(value = "SELECT COUNT(DISTINCT customer_id) FROM rental", nativeQuery = true)
    long activeCustomers();
}
