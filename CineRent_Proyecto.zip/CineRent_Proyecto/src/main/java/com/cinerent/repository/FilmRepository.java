package com.cinerent.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cinerent.model.Film;

public interface FilmRepository extends JpaRepository<Film, Integer> {

    /**
     * Native query (PostgreSQL) usando ILIKE para búsqueda case-insensitive.
     * Compatible con Pagila (ENUM mpaa_rating).
     */
    @Query(
        value = """
            SELECT DISTINCT f.*
            FROM film f
            LEFT JOIN film_category fc ON f.film_id = fc.film_id
            LEFT JOIN category c ON c.category_id = fc.category_id
            LEFT JOIN film_actor fa ON f.film_id = fa.film_id
            LEFT JOIN actor a ON a.actor_id = fa.actor_id
            WHERE (:title IS NULL OR f.title ILIKE CONCAT('%', :title, '%'))
              AND (:rating IS NULL OR f.rating = CAST(:rating AS mpaa_rating))
              AND (:categoryId IS NULL OR c.category_id = :categoryId)
              AND (:actor IS NULL OR (a.first_name || ' ' || a.last_name) ILIKE CONCAT('%', :actor, '%'))
            ORDER BY f.title
        """,
        countQuery = """
            SELECT COUNT(DISTINCT f.film_id)
            FROM film f
            LEFT JOIN film_category fc ON f.film_id = fc.film_id
            LEFT JOIN category c ON c.category_id = fc.category_id
            LEFT JOIN film_actor fa ON f.film_id = fa.film_id
            LEFT JOIN actor a ON a.actor_id = fa.actor_id
            WHERE (:title IS NULL OR f.title ILIKE CONCAT('%', :title, '%'))
              AND (:rating IS NULL OR f.rating = CAST(:rating AS mpaa_rating))
              AND (:categoryId IS NULL OR c.category_id = :categoryId)
              AND (:actor IS NULL OR (a.first_name || ' ' || a.last_name) ILIKE CONCAT('%', :actor, '%'))
        """,
        nativeQuery = true
    )
    Page<Film> search(
        @Param("title") String title,
        @Param("rating") String rating,
        @Param("categoryId") Integer categoryId,
        @Param("actor") String actor,
        Pageable pageable
    );
}
