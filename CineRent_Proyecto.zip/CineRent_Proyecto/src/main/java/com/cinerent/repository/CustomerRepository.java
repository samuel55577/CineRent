package com.cinerent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cinerent.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    @Query(value = """
        SELECT *
        FROM customer c
        WHERE (:name IS NULL
           OR (c.first_name || ' ' || c.last_name)
              ILIKE CONCAT('%', :name, '%'))
        ORDER BY c.last_name, c.first_name
        """, nativeQuery = true)
    List<Customer> search(@Param("name") String name);
}
