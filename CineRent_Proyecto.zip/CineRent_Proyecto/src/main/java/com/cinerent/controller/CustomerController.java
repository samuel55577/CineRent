package com.cinerent.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cinerent.repository.CustomerRepository;
import com.cinerent.service.CustomerHistoryService;

@Controller
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerRepository customerRepository;
    private final CustomerHistoryService historyService;

    public CustomerController(CustomerRepository customerRepository,
                              CustomerHistoryService historyService) {
        this.customerRepository = customerRepository;
        this.historyService = historyService;
    }

    @GetMapping
    public String customers(@RequestParam(required = false) String name, Model model) {
        model.addAttribute(
            "customers",
            customerRepository.search(
                name == null || name.isBlank() ? null : name
            )
        );
        model.addAttribute("name", name);
        return "customers";
    }

    @GetMapping("/{id}")
    public String customerDetail(@PathVariable Integer id, Model model) {

        model.addAttribute(
            "customer",
            customerRepository.findById(id).orElseThrow()
        );

        model.addAttribute(
            "rentals",
            historyService.rentalsByCustomer(id)
        );

        model.addAttribute(
            "payments",
            historyService.paymentsByCustomer(id)
        );

        return "customer-detail";
    }
}


