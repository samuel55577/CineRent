package com.cinerent.controller;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cinerent.repository.CategoryRepository;
import com.cinerent.repository.FilmRepository;

@Controller
@RequestMapping("/films")
public class FilmController {

    private final FilmRepository filmRepository;
    private final CategoryRepository categoryRepository;

    public FilmController(FilmRepository filmRepository,
                          CategoryRepository categoryRepository) {
        this.filmRepository = filmRepository;
        this.categoryRepository = categoryRepository;
    }

    @GetMapping
    public String listFilms(
        @RequestParam(required = false) String title,
        @RequestParam(required = false) String rating,
        @RequestParam(required = false) Integer categoryId,
        @RequestParam(required = false) String actor,   // 👈 mismo nombre
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size,
        Model model
    ) {

        Pageable pageable =
            PageRequest.of(page, size, Sort.by("title").ascending());

        var films = filmRepository.search(
            emptyToNull(title),
            emptyToNull(rating),
            categoryId,
            emptyToNull(actor),
            pageable
        );

        model.addAttribute("films", films);
        model.addAttribute("categories",
            categoryRepository.findAll(Sort.by("name")));

        // mantener filtros en la vista
        model.addAttribute("title", title);
        model.addAttribute("rating", rating);
        model.addAttribute("categoryId", categoryId);
        model.addAttribute("actor", actor);
        model.addAttribute("size", size);

        return "films";
    }

    private String emptyToNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }
}
