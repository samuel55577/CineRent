package com.cinerent.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cinerent.repository.DashboardRepository;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    private final DashboardRepository dashboardRepository;

    public DashboardController(DashboardRepository dashboardRepository) {
        this.dashboardRepository = dashboardRepository;
    }

    @GetMapping
    public String dashboard(Model model) {

        model.addAttribute("totalRentals",
            dashboardRepository.totalRentals());

        model.addAttribute("totalIncome",
            dashboardRepository.totalIncome());

        model.addAttribute("activeCustomers",
            dashboardRepository.activeCustomers());

        return "dashboard";
    }
}
