package com.cinerent.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.*;

@Entity
@Table(name = "film")
public class Film {

  @Id
  @Column(name = "film_id")
  private Integer id;

  @Column(name = "title")
  private String title;

  @Column(name = "rating")
  private String rating;

  @Column(name = "length")
  private Integer length;

  @ManyToMany(fetch = FetchType.LAZY)
  @JoinTable(
    name = "film_category",
    joinColumns = @JoinColumn(name = "film_id"),
    inverseJoinColumns = @JoinColumn(name = "category_id")
  )
  private Set<Category> categories = new HashSet<>();

  @ManyToMany(fetch = FetchType.LAZY)
  @JoinTable(
    name = "film_actor",
    joinColumns = @JoinColumn(name = "film_id"),
    inverseJoinColumns = @JoinColumn(name = "actor_id")
  )
  private Set<Actor> actors = new HashSet<>();

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }

  public String getTitle() { return title; }
  public void setTitle(String title) { this.title = title; }

  public String getRating() { return rating; }
  public void setRating(String rating) { this.rating = rating; }

  public Integer getLength() { return length; }
  public void setLength(Integer length) { this.length = length; }

  public Set<Category> getCategories() { return categories; }
  public void setCategories(Set<Category> categories) { this.categories = categories; }

  public Set<Actor> getActors() { return actors; }
  public void setActors(Set<Actor> actors) { this.actors = actors; }
}
