package com.cinerent.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

@Service
public class ReportService {

    @PersistenceContext
    private EntityManager em;

    // Reporte 1: Ingresos por mes
    public List<Object[]> monthlyIncome() {
        return em.createNativeQuery("""
            SELECT
                TO_CHAR(payment_date, 'YYYY-MM') AS month,
                SUM(amount) AS total
            FROM payment
            GROUP BY TO_CHAR(payment_date, 'YYYY-MM')
            ORDER BY month
        """).getResultList();
    }

    // Reporte 2: Top películas más alquiladas
    public List<Object[]> topFilms() {
        return em.createNativeQuery("""
            SELECT
                f.title,
                COUNT(*) AS total_rentals
            FROM rental r
            JOIN inventory i ON r.inventory_id = i.inventory_id
            JOIN film f ON i.film_id = f.film_id
            GROUP BY f.title
            ORDER BY total_rentals DESC
            LIMIT 10
        """).getResultList();
    }
}
