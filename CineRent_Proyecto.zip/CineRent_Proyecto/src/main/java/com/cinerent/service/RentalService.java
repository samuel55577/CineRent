package com.cinerent.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

@Service
public class RentalService {

    @PersistenceContext
    private EntityManager em;

    /**
     * Lista alquileres filtrando por rango de fechas (opcional) y tienda (opcional).
     * - fromDate y toDate deben llegar como "YYYY-MM-DD"
     * - storeId: 1 o 2 (en Pagila normalmente)
     */
    public List<Object[]> searchRentals(String fromDate, String toDate, Integer storeId) {

        String sql = """
            SELECT
                r.rental_date,
                f.title,
                (c.first_name || ' ' || c.last_name) AS customer_name,
                s.store_id,
                r.return_date
            FROM rental r
            JOIN customer c   ON r.customer_id = c.customer_id
            JOIN inventory i  ON r.inventory_id = i.inventory_id
            JOIN film f       ON i.film_id = f.film_id
            JOIN store s      ON i.store_id = s.store_id
            WHERE 1=1
        """;

        if (fromDate != null && !fromDate.isBlank()) {
            sql += " AND r.rental_date >= CAST(:fromDate AS date) ";
        }
        if (toDate != null && !toDate.isBlank()) {
            // hasta el final del día (inclusive)
            sql += " AND r.rental_date < (CAST(:toDate AS date) + INTERVAL '1 day') ";
        }
        if (storeId != null) {
            sql += " AND s.store_id = :storeId ";
        }

        sql += " ORDER BY r.rental_date DESC LIMIT 200 ";

        var q = em.createNativeQuery(sql);

        if (fromDate != null && !fromDate.isBlank()) q.setParameter("fromDate", fromDate);
        if (toDate != null && !toDate.isBlank()) q.setParameter("toDate", toDate);
        if (storeId != null) q.setParameter("storeId", storeId);

        return q.getResultList();
    }
}
