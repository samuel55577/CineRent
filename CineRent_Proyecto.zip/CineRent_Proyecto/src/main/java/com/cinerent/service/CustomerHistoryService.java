package com.cinerent.service;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

@Service
public class CustomerHistoryService {

    @PersistenceContext
    private EntityManager em;

    public List<Object[]> rentalsByCustomer(Integer customerId) {
        return em.createNativeQuery("""
            SELECT r.rental_date, f.title, r.return_date
            FROM rental r
            JOIN inventory i ON r.inventory_id = i.inventory_id
            JOIN film f ON i.film_id = f.film_id
            WHERE r.customer_id = :customerId
            ORDER BY r.rental_date DESC
        """)
        .setParameter("customerId", customerId)
        .getResultList();
    }

    public List<Object[]> paymentsByCustomer(Integer customerId) {
        return em.createNativeQuery("""
            SELECT p.payment_date, p.amount
            FROM payment p
            WHERE p.customer_id = :customerId
            ORDER BY p.payment_date DESC
        """)
        .setParameter("customerId", customerId)
        .getResultList();
    }
}
