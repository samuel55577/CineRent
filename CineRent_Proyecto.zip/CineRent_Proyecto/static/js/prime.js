document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".reveal").forEach((el, i) => {
    el.style.animationDelay = `${i * 60}ms`;
  });
});
